import os
from flask import Flask, render_template, request, redirect, url_for, session
from controllers import EstoqueController
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "segredo123"  # usado para sessões (login)
controller = EstoqueController()

# Configuração de uploads de imagens
UPLOAD_FOLDER = os.path.join("static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
ALLOWED_EXT = {"png", "jpg", "jpeg", "gif"}  # formatos aceitos

def allowed_filename(filename):
    """Verifica se o arquivo de imagem tem uma extensão válida"""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


# ---------------- ROTAS PRINCIPAIS ---------------- #

@app.route("/", methods=["GET", "POST"])
def login():
    """Tela de login do sistema"""
    if request.method == "POST":
        usuario = request.form["usuario"]
        senha = request.form["senha"]
        if controller.autenticar_usuario(usuario, senha):  # confere usuário e senha
            session["usuario"] = usuario  # guarda usuário logado
            return redirect(url_for("index"))  # vai para página inicial
        return render_template("login.html", erro="Usuário ou senha inválidos!")
    return render_template("login.html")


@app.route("/logout")
def logout():
    """Sai do sistema e limpa a sessão"""
    session.pop("usuario", None)
    return redirect(url_for("login"))


@app.route("/index")
def index():
    """Página inicial com atalhos (cadastrar, listar, etc.)"""
    if "usuario" not in session:
        return redirect(url_for("login"))
    return render_template("index.html")


@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    """Cadastro de um novo produto no estoque"""
    if "usuario" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        # pega os dados do formulário
        id = request.form["id"]
        nome = request.form["nome"]
        categoria = request.form["categoria"]
        tamanho = request.form["tamanho"]
        quantidade = int(request.form["quantidade"])
        preco_compra = float(request.form["preco_compra"])
        preco_venda = float(request.form["preco_venda"])
        fornecedor = request.form["fornecedor"]

        # upload de imagem (opcional)
        imagem = request.files.get("imagem")
        imagem_nome = None
        if imagem and imagem.filename and allowed_filename(imagem.filename):
            imagem_nome = secure_filename(imagem.filename)
            imagem.save(os.path.join(app.config["UPLOAD_FOLDER"], imagem_nome))

        # chama o controller para salvar
        controller.cadastrar_produto(
            id, nome, categoria, tamanho, quantidade,
            preco_compra, preco_venda, fornecedor, imagem_nome
        )
        return redirect(url_for("listar"))  # depois do cadastro vai para listagem

    return render_template("cadastro.html")


@app.route("/listar")
def listar():
    """Listagem de produtos com filtros (nome, categoria, tamanho) e ordenação"""
    if "usuario" not in session:
        return redirect(url_for("login"))

    # pega parâmetros da URL (?nome=...&categoria=... etc.)
    categoria = request.args.get("categoria", "").lower()
    tamanho = request.args.get("tamanho", "").lower()
    nome = request.args.get("nome", "").lower()
    ordenar = request.args.get("ordenar", "nome")
    ordem = request.args.get("ordem", "asc")

    produtos = controller.listar_produtos()

    # aplica filtros
    if categoria:
        produtos = [p for p in produtos if categoria in p.categoria.lower()]
    if tamanho:
        produtos = [p for p in produtos if tamanho in p.tamanho.lower()]
    if nome:
        produtos = [p for p in produtos if nome in p.nome.lower()]

    # aplica ordenação
    if ordenar == "nome":
        produtos.sort(key=lambda p: p.nome.lower(), reverse=(ordem == "desc"))
    elif ordenar == "preco":
        produtos.sort(key=lambda p: p.preco_venda, reverse=(ordem == "desc"))
    elif ordenar == "quantidade":
        produtos.sort(key=lambda p: p.quantidade, reverse=(ordem == "desc"))

    return render_template("listar.html", produtos=produtos,
                           categoria=categoria, tamanho=tamanho, nome=nome,
                           ordenar=ordenar, ordem=ordem)


@app.route("/produto/<int:indice>")
def produto(indice):
    """Página de detalhes de um produto específico"""
    if "usuario" not in session:
        return redirect(url_for("login"))
    produtos = controller.listar_produtos()
    if 0 <= indice < len(produtos):
        return render_template("produto.html", produto=produtos[indice], indice=indice)
    return redirect(url_for("listar"))


@app.route("/editar/<int:indice>", methods=["GET", "POST"])
def editar(indice):
    """Edição de um produto existente"""
    if "usuario" not in session:
        return redirect(url_for("login"))

    produtos = controller.listar_produtos()
    if not (0 <= indice < len(produtos)):
        return redirect(url_for("listar"))

    produto = produtos[indice]

    if request.method == "POST":
        # atualiza os dados
        produto.id = request.form["id"]
        produto.nome = request.form["nome"]
        produto.categoria = request.form["categoria"]
        produto.tamanho = request.form["tamanho"]
        produto.quantidade = int(request.form["quantidade"])
        produto.preco_compra = float(request.form["preco_compra"])
        produto.preco_venda = float(request.form["preco_venda"])
        produto.fornecedor = request.form["fornecedor"]

        # upload nova imagem (opcional)
        imagem = request.files.get("imagem")
        if imagem and imagem.filename and allowed_filename(imagem.filename):
            imagem_nome = secure_filename(imagem.filename)
            imagem.save(os.path.join(app.config["UPLOAD_FOLDER"], imagem_nome))
            produto.imagem = imagem_nome

        return redirect(url_for("produto", indice=indice))  # volta para detalhes

    return render_template("editar.html", produto=produto, indice=indice)


@app.route("/remover/<int:indice>")
def remover(indice):
    """Remove um produto do estoque"""
    if "usuario" not in session:
        return redirect(url_for("login"))
    controller.remover_produto(indice)
    return redirect(url_for("listar"))


# Início do servidor
if __name__ == "__main__":
    app.run(debug=True)
